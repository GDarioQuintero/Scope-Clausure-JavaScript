// eslint-disable-next-line no-use-before-define
nameOfDog('Zero ');

function nameOfDog(name) {
  console.log(name);
}
