/* eslint-disable no-unused-vars */
/* eslint-disable no-var */

const animals = () => {
  var animal = 'Pejelagarto';
  return animal;
};
// console.log(animal);

const anotherFunc = () => {
  var x = 1;
  var y = 2;
  console.log(x, y);
};

anotherFunc();
